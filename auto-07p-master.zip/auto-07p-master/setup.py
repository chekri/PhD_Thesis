from setuptools import setup

setup(package_dir={'': 'python'})
