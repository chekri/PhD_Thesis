#! /usr/bin/env python

# Some ways to run AUTO:
# a) python auto
# b) import auto
#    auto.auto()
# c) from auto import *

if __name__ == "__main__":
    from auto import AUTOclui
    AUTOclui.auto()
else:
    from auto.AUTOclui import *
