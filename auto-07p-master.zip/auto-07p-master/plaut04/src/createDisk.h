#ifndef CREATEDISK_H
#define CREATEDISK_H

#include <Inventor/nodes/SoSeparator.h>
SoSeparator *createDisk(float where[], float scaler);

#endif
